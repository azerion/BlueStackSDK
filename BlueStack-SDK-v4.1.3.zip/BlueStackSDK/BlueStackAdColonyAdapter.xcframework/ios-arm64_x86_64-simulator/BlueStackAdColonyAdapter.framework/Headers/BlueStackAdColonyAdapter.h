//
//  BlueStackAdColonyAdapter.h
//  BlueStackAdColonyAdapter
//
//  Created by Hussein Dimessi on 11/2/20.
//

#import <Foundation/Foundation.h>

//! Project version number for BlueStackAdColonyAdapter.
FOUNDATION_EXPORT double BlueStackAdColonyAdapterVersionNumber;

//! Project version string for BlueStackAdColonyAdapter.
FOUNDATION_EXPORT const unsigned char BlueStackAdColonyAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BlueStackAdColonyAdapter/PublicHeader.h>


