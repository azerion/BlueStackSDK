//
//  BluestackAmazonPublisherServicesAdapter.h
//  BluestackAmazonPublisherServicesAdapter
//
//  Created by Yecine Dhouib on 04/06/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for BluestackAmazonPublisherServicesAdapter.
FOUNDATION_EXPORT double BluestackAmazonPublisherServicesAdapterVersionNumber;

//! Project version string for BluestackAmazonPublisherServicesAdapter.
FOUNDATION_EXPORT const unsigned char BluestackAmazonPublisherServicesAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BluestackAmazonPublisherServicesAdapter/PublicHeader.h>


