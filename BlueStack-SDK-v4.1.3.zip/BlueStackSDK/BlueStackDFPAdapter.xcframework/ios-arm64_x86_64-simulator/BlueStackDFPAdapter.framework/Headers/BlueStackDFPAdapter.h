//
//  BlueStackDFPAdapter.h
//  BlueStackDFPAdapter
//
//  Created by Hussein Dimessi on 11/2/20.
//

#import <Foundation/Foundation.h>

//! Project version number for BlueStackDFPAdapter.
FOUNDATION_EXPORT double BlueStackDFPAdapterVersionNumber;

//! Project version string for BlueStackDFPAdapter.
FOUNDATION_EXPORT const unsigned char BlueStackDFPAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BlueStackDFPAdapter/PublicHeader.h>


