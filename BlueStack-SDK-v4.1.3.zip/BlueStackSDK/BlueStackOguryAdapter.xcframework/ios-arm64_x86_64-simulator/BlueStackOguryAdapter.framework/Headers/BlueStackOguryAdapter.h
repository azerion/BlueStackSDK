//
//  BlueStackOguryAdapter.h
//  BlueStackOguryAdapter
//
//  Created by Hussein Dimessi on 11/2/20.
//

#import <Foundation/Foundation.h>

//! Project version number for BlueStackOguryAdapter.
FOUNDATION_EXPORT double BlueStackOguryAdapterVersionNumber;

//! Project version string for BlueStackOguryAdapter.
FOUNDATION_EXPORT const unsigned char BlueStackOguryAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BlueStackOguryAdapter/PublicHeader.h>


